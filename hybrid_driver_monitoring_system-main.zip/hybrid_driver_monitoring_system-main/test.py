import torch
from torchvision import models, transforms
from PIL import Image

# Load model
model = models.resnet18(pretrained=False)
model.fc = torch.nn.Linear(model.fc.in_features, 2)
model.load_state_dict(torch.load("drowsiness_model.pth"))
model.eval()

transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
])

def predict(image_path):
    image = Image.open(image_path).convert("RGB")
    image = transform(image).unsqueeze(0)

    with torch.no_grad():
        output = model(image)
        _, pred = torch.max(output, 1)

    return pred.item()

# Test few images
for i in [10, 200, 500, 1000]:
    img_path = f"frames/{i:06d}.jpg"
    result = predict(img_path)

    label = "Drowsy" if result == 1 else "Alert"
    print(f"{img_path} → {label}")

import cv2
import os

video_path = "gB_10_s5_2019-03-12T10;35;20+01;00_rgb_face.mp4"
output_folder = "frames"

os.makedirs(output_folder, exist_ok=True)

cap = cv2.VideoCapture(video_path)

frame_id = 0

while True:
    ret, frame = cap.read()
    if not ret:
        break

    filename = os.path.join(output_folder, f"{frame_id:06d}.jpg")
    cv2.imwrite(filename, frame)

    frame_id += 1

cap.release()
print("Done extracting frames")

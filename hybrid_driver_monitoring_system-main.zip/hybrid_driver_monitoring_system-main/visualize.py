import json
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os
from sklearn.metrics import (
    confusion_matrix,
    classification_report,
    roc_curve,
    auc,
    precision_recall_curve
)

output_dir = "plots"
os.makedirs(output_dir, exist_ok=True)

# Load data
with open("training_log.json") as f:
    history = json.load(f)

loss = history["loss"]
acc = history["accuracy"]
labels = np.array(history["all_labels"])
preds = np.array(history["all_preds"])
probs = np.array(history["probs"])

# -------------------------
# 1. Training Curves
# -------------------------
plt.figure()
plt.plot(acc, label="Accuracy")
plt.plot(loss, label="Loss")
plt.xlabel("Epoch")
plt.ylabel("Value")
plt.title("Training Curves")
plt.legend()
plt.grid()
plt.savefig(os.path.join(output_dir, "training_curves.png"))

# -------------------------
# 2. Confusion Matrix
# -------------------------
cm = confusion_matrix(labels, preds)

plt.figure()
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
            xticklabels=["Alert", "Drowsy"],
            yticklabels=["Alert", "Drowsy"])
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.title("Confusion Matrix")
plt.savefig(os.path.join(output_dir, "confusion_matrix.png"))

# -------------------------
# 3. Classification Report
# -------------------------
print("\nClassification Report:\n")
print(classification_report(labels, preds))

# -------------------------
# 4. ROC Curve
# -------------------------
fpr, tpr, _ = roc_curve(labels, probs)
roc_auc = auc(fpr, tpr)

plt.figure()
plt.plot(fpr, tpr, label=f"AUC = {roc_auc:.2f}")
plt.plot([0,1], [0,1], linestyle='--')
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("ROC Curve")
plt.legend()
plt.grid()
plt.savefig(os.path.join(output_dir, "roc_curve.png"))

# -------------------------
# 5. Precision-Recall Curve
# -------------------------
precision, recall, _ = precision_recall_curve(labels, probs)

plt.figure()
plt.plot(recall, precision)
plt.xlabel("Recall")
plt.ylabel("Precision")
plt.title("Precision-Recall Curve")
plt.grid()
plt.savefig(os.path.join(output_dir, "pr_curve.png"))

# -------------------------
# 6. Prediction Distribution
# -------------------------
plt.figure()
plt.hist(preds, bins=2)
plt.xticks([0,1], ["Alert", "Drowsy"])
plt.title("Prediction Distribution")
plt.savefig(os.path.join(output_dir, "prediction_distribution.png"))

# -------------------------
# 7. Confidence Histogram
# -------------------------
plt.figure()
plt.hist(probs, bins=20)
plt.xlabel("Drowsy Probability")
plt.ylabel("Frequency")
plt.title("Confidence Histogram")
plt.savefig(os.path.join(output_dir, "confidence_histogram.png"))

# -------------------------
# 8. Confidence by Class
# -------------------------
plt.figure()
plt.hist(probs[labels == 0], bins=20, alpha=0.5, label="Alert")
plt.hist(probs[labels == 1], bins=20, alpha=0.5, label="Drowsy")
plt.legend()
plt.xlabel("Drowsy Probability")
plt.title("Confidence by Class")
plt.savefig(os.path.join(output_dir, "confidence_by_class.png"))

# -------------------------
# 9. Error Analysis
# -------------------------
errors = preds != labels

plt.figure()
plt.hist(preds[errors], bins=2)
plt.xticks([0,1], ["Pred Alert", "Pred Drowsy"])
plt.title("Misclassification Distribution")
plt.savefig(os.path.join(output_dir, "error_analysis.png"))

print("\nAll plots saved successfully.")
import sys
import time
from collections import deque
from pathlib import Path

import cv2
import torch
from PIL import Image
from torchvision import models, transforms


BASE_DIR = Path(__file__).resolve().parent
MINOR_DIR = BASE_DIR / "minor"
if str(MINOR_DIR) not in sys.path:
    sys.path.insert(0, str(MINOR_DIR))

from steeringanalysis import analyze_steering, get_joystick_steering


DISTRACTION_TIME = 3
HEAD_OFFSET_THRESHOLD = 0.22

pred_buffer = deque(maxlen=10)
distraction_start = None


def load_model():
    model = models.resnet18(pretrained=False)
    model.fc = torch.nn.Linear(model.fc.in_features, 2)
    model_path = BASE_DIR / "drowsiness_model.pth"
    model.load_state_dict(torch.load(model_path, map_location="cpu"))
    model.eval()
    return model


def get_ml_status(model, transform, frame):
    img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    img = Image.fromarray(img)
    img = transform(img).unsqueeze(0)

    with torch.no_grad():
        output = model(img)
        _, pred = torch.max(output, 1)

    pred_buffer.append(pred.item())
    drowsy_count = sum(pred_buffer)

    if drowsy_count > 6:
        return "DROWSY", (0, 0, 255)

    return "ALERT", (0, 255, 0)


def get_head_status(frame, gray, faces, eye_cascade):
    global distraction_start

    text = "FOCUSED"

    if len(faces) > 0:
        x, y, w, h = max(faces, key=lambda face: face[2] * face[3])
        face_center = x + (w / 2)
        frame_center = frame.shape[1] / 2
        center_offset = abs(face_center - frame_center) / frame.shape[1]

        face_region = gray[y:y + h, x:x + w]
        eyes = eye_cascade.detectMultiScale(face_region, scaleFactor=1.1, minNeighbors=5)
        is_turning = center_offset > HEAD_OFFSET_THRESHOLD or len(eyes) == 1

        if is_turning:
            if distraction_start is None:
                distraction_start = time.time()

            if time.time() - distraction_start > DISTRACTION_TIME:
                text = "DISTRACTED"
            else:
                text = "TURNING"
        else:
            distraction_start = None
            text = "FOCUSED"
    else:
        if distraction_start is None:
            distraction_start = time.time()

        if time.time() - distraction_start > DISTRACTION_TIME:
            text = "DISTRACTED"
        else:
            text = "NO_FACE"

    return text


def get_risk_status(ml_status, head_status, steering_status):
    head_risk = head_status == "DISTRACTED"
    steering_risk = steering_status == "DROWSY"
    ml_risk = ml_status == "DROWSY"

    if (ml_risk and (head_risk or steering_risk)) or (head_risk and steering_risk):
        return "HIGH RISK"

    if ml_risk or head_risk or steering_risk:
        return "MEDIUM RISK"

    return "SAFE"


def draw_status_panel(frame, ml_status, head_status, steering_status, risk, angle, variance, freq):
    risk_color = (0, 0, 255) if risk == "HIGH RISK" else (0, 165, 255) if risk == "MEDIUM RISK" else (0, 255, 0)

    steering_text = f"Steering: {steering_status}"
    if angle is not None:
        steering_text += f" ({angle:.1f} deg)"

    lines = [
        (f"ML: {ml_status}", (20, 40), (255, 255, 255), 0.8, 2),
        (f"Head: {head_status}", (20, 75), (255, 255, 255), 0.8, 2),
        (steering_text, (20, 110), (255, 255, 255), 0.8, 2),
        (f"Var: {variance:.2f}  Freq: {freq:.3f}", (20, 145), (255, 255, 255), 0.7, 2),
        (f"Risk: {risk}", (20, 190), risk_color, 1.0, 3),
    ]

    for text, origin, color, scale, thickness in lines:
        cv2.putText(frame, text, origin, cv2.FONT_HERSHEY_SIMPLEX, scale, color, thickness)


def main():
    face_cascade = cv2.CascadeClassifier(
        cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
    )
    eye_cascade = cv2.CascadeClassifier(
        cv2.data.haarcascades + "haarcascade_eye.xml"
    )

    model = load_model()
    transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
    ])

    cap = cv2.VideoCapture(0)

    if not cap.isOpened():
        print("Error: Cannot access webcam")
        return

    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                break

            frame = cv2.flip(frame, 1)

            ml_status, ml_color = get_ml_status(model, transform, frame)

            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = face_cascade.detectMultiScale(gray, 1.3, 5)
            head_status = get_head_status(frame, gray, faces, eye_cascade)

            angle = get_joystick_steering()
            steering_status, variance, freq = analyze_steering(angle)
            risk = get_risk_status(ml_status, head_status, steering_status)

            if len(faces) > 0:
                x, y, w, h = max(faces, key=lambda face: face[2] * face[3])
                cv2.rectangle(frame, (x, y), (x + w, y + h), ml_color, 2)
                cv2.putText(frame, ml_status, (x, y - 10),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.8, ml_color, 2)
            else:
                cv2.putText(frame, ml_status, (50, 50),
                            cv2.FONT_HERSHEY_SIMPLEX, 1, ml_color, 2)

            draw_status_panel(
                frame,
                ml_status,
                head_status,
                steering_status,
                risk,
                angle,
                variance,
                freq,
            )

            print(
                f"ML: {ml_status} | Head: {head_status} | "
                f"Steering: {steering_status} | Risk: {risk}"
            )

            cv2.imshow("Driver Monitoring", frame)

            key = cv2.waitKey(1) & 0xFF
            if key == ord("q") or key == 27:
                break
    finally:
        cap.release()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()

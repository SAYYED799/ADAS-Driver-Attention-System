import cv2
import time

cap = None
face_cascade = None
eye_cascade = None

distraction_start = None
DISTRACTION_TIME = 3  # seconds


def get_camera():
    global cap

    if cap is None:
        cap = cv2.VideoCapture(0)

    return cap


def get_cascades():
    global face_cascade, eye_cascade

    if face_cascade is None:
        face_cascade = cv2.CascadeClassifier(
            cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
        )
    if eye_cascade is None:
        eye_cascade = cv2.CascadeClassifier(
            cv2.data.haarcascades + "haarcascade_eye.xml"
        )

    return face_cascade, eye_cascade


def get_head_status():
    global distraction_start

    camera = get_camera()
    success, frame = camera.read()
    if not success:
        return "UNKNOWN", None

    frame = cv2.flip(frame, 1)
    text = "FOCUSED"

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    face_detector, eye_detector = get_cascades()
    faces = face_detector.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)

    if len(faces) > 0:
        x, y, w, h = max(faces, key=lambda face: face[2] * face[3])
        face_center = x + (w / 2)
        frame_center = frame.shape[1] / 2
        center_offset = abs(face_center - frame_center) / frame.shape[1]

        face_region = gray[y:y + h, x:x + w]
        eyes = eye_detector.detectMultiScale(face_region, scaleFactor=1.1, minNeighbors=5)
        is_turning = center_offset > 0.22 or len(eyes) == 1

        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

        if is_turning:
            if distraction_start is None:
                distraction_start = time.time()

            if time.time() - distraction_start > DISTRACTION_TIME:
                text = "DISTRACTED"
            else:
                text = "TURNING"
        else:
            distraction_start = None
            text = "FOCUSED"
    else:
        if distraction_start is None:
            distraction_start = time.time()

        if time.time() - distraction_start > DISTRACTION_TIME:
            text = "DISTRACTED"
        else:
            text = "NO_FACE"

    cv2.putText(frame, f"Head: {text}", (20, 50),
                cv2.FONT_HERSHEY_SIMPLEX,
                1, (0, 0, 255), 3)

    return text, frame


def release_head_resources():
    if cap is not None:
        cap.release()


# ==================================================
# Standalone execution
# ==================================================
if __name__ == "__main__":

    while True:
        status, frame = get_head_status()

        if frame is not None:
            cv2.imshow("Driver Monitoring", frame)

        if cv2.waitKey(1) & 0xFF == 27:
            break

    release_head_resources()
    cv2.destroyAllWindows()

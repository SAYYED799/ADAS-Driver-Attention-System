import torch
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt
import json
from sklearn.metrics import confusion_matrix
import seaborn as sns
from sklearn.metrics import classification_report
from torch.utils.data import DataLoader, Dataset
from torchvision import models, transforms
import pandas as pd
from PIL import Image
import os

history = {
    "loss": [],
    "accuracy": [],
    "all_preds": [],
    "all_labels": [],
    "probs": [] 
}
# -------------------------
# Dataset Class
# -------------------------
class DrowsinessDataset(Dataset):
    def __init__(self, csv_file, image_folder):
        self.data = pd.read_csv(csv_file)
        self.image_folder = image_folder

        self.transform = transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
        ])

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        frame_id = int(self.data.iloc[idx]["frame_id"])
        label = int(self.data.iloc[idx]["label"])

        img_path = os.path.join(self.image_folder, f"{frame_id:06d}.jpg")

        image = Image.open(img_path).convert("RGB")
        image = self.transform(image)

        return image, label

# -------------------------
# Load Dataset
# -------------------------
dataset = DrowsinessDataset("drowsy_labels.csv", "frames")

train_loader = DataLoader(dataset, batch_size=32, shuffle=True)

# -------------------------
# Model (ResNet18)
# -------------------------
model = models.resnet18(pretrained=True)

# Replace last layer
model.fc = nn.Linear(model.fc.in_features, 2)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = model.to(device)

# -------------------------
# Training Setup
# -------------------------
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.0001)
all_preds = []
all_labels = []
losses = []
accuracies = []
all_preds = []
all_labels = []
# -------------------------
# Training Loop
# -------------------------
epochs = 5

for epoch in range(epochs):
    total_loss = 0
    running_loss=0.0
    correct = 0
    total = 0

    for images, labels in train_loader:
        images, labels = images.to(device), labels.to(device)

        optimizer.zero_grad()

        outputs = model(images)
        loss = criterion(outputs, labels)
        
        # Get predictions
        _, preds = torch.max(outputs, 1)

        # 🔥 Store predictions & labels
        history["all_preds"].extend(preds.cpu().numpy().tolist())
        history["all_labels"].extend(labels.cpu().numpy().tolist())

        # 🔥 OPTIONAL: store probabilities
        probs = torch.softmax(outputs, dim=1)[:, 1]  # probability of DROWSY
        history["probs"].extend(probs.detach().cpu().numpy().tolist())

        
        loss.backward()
        optimizer.step()

        total_loss += loss.item()

        _, predicted = torch.max(outputs, 1)
        all_preds.extend(predicted.cpu().numpy())
        all_labels.extend(labels.cpu().numpy())
        correct += (predicted == labels).sum().item()
        total += labels.size(0)
        
        all_preds.extend(predicted.cpu().numpy())
        all_labels.extend(labels.cpu().numpy())


    accuracy = 100 * correct / total
    losses.append(total_loss)
    accuracies.append(accuracy)
    print(f"Epoch {epoch+1}: Loss={total_loss:.4f}, Accuracy={accuracy:.2f}%")
    epoch_loss = running_loss / len(train_loader)
    epoch_acc = correct / total

    history["loss"].append(epoch_loss)
    history["accuracy"].append(epoch_acc)

with open("training_log.json", "w") as f:
    json.dump(history, f)

print("Training log saved as training_log.json")

cm = confusion_matrix(all_labels, all_preds)

plt.figure(figsize=(6,5))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
            xticklabels=["Alert", "Drowsy"],
            yticklabels=["Alert", "Drowsy"])

plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.title("Confusion Matrix")

plt.savefig("confusion_matrix.png")
print("Confusion matrix saved")

print("Training complete")

print("\nClassification Report:")
print(classification_report(all_labels, all_preds))

plt.plot(accuracies)
plt.title("Accuracy vs Epoch")
plt.xlabel("Epoch")
plt.ylabel("Accuracy")
plt.grid()

plt.savefig("accuracy_plot.png")
print("Plot saved")

torch.save(model.state_dict(), "drowsiness_model.pth")
print("Model saved")

import numpy as np
import os
import time

try:
    import pygame
except ModuleNotFoundError:
    pygame = None


joystick = None
joystick_error = None


def init_joystick():
    global joystick, joystick_error

    if joystick is not None:
        return joystick

    if pygame is None:
        joystick_error = "pygame is not installed"
        return None

    try:
        os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
        pygame.display.init()
        pygame.joystick.init()

        if pygame.joystick.get_count() == 0:
            joystick_error = "No joystick connected"
            return None

        joystick = pygame.joystick.Joystick(0)
        joystick.init()
        print("Joystick connected:", joystick.get_name())
        return joystick
    except pygame.error as exc:
        joystick_error = str(exc)
        joystick = None
        return None

# Store last steering values
steering_history = []


def get_joystick_steering():
    active_joystick = init_joystick()

    if active_joystick is None:
        return None

    pygame.event.pump()  # Update joystick events

    # Usually axis 0 = left-right stick
    axis_value = active_joystick.get_axis(0)

    # Convert to steering angle range (-30 to +30 degrees)
    steering_angle = axis_value * 30

    return steering_angle


def analyze_steering(angle):
    if angle is None:
        steering_history.clear()
        return "NO_JOYSTICK", 0, 0

    steering_history.append(angle)

    if len(steering_history) > 100:
        steering_history.pop(0)

    if len(steering_history) < 20:
        return "Collecting", 0, 0

    variance = np.var(steering_history)

    # Count micro-corrections (sign changes)
    corrections = 0
    for i in range(1, len(steering_history)):
        if np.sign(steering_history[i]) != np.sign(steering_history[i - 1]):
            corrections += 1

    correction_frequency = corrections / len(steering_history)

    if variance > 200 or correction_frequency < 0.01:
        return "DROWSY", variance, correction_frequency
    else:
        return "ALERT", variance, correction_frequency


# Standalone test
if __name__ == "__main__":
    while True:
        angle = get_joystick_steering()
        status, var, freq = analyze_steering(angle)

        if angle is None:
            print(f"Angle: N/A | Var: {var:.2f} | Freq: {freq:.3f} | Status: {status}")
        else:
            print(f"Angle: {angle:.2f} | Var: {var:.2f} | Freq: {freq:.3f} | Status: {status}")

        time.sleep(0.1)

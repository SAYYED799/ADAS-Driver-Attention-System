import json
import csv

json_path = "/home/samar/Documents/DMD Datasets/dmd-dataset-mini-sample-gB-10-s5/dmd/gB/10/s5/gB_10_s5_2019-03-12T10;35;20+01;00_rgb_ann_drowsiness.json"

def load_json(path):
    with open(path, "r") as f:
        return json.load(f)

def build_action_map(data):
    action_map = {}
    actions = data["openlabel"]["actions"]

    for action_id, action_info in actions.items():
        action_map[action_id] = action_info["type"]

    return action_map

def extract_frame_labels(data, action_map):
    frame_labels = {}
    frames = data["openlabel"]["frames"]

    for frame_id, frame_content in frames.items():
        actions = frame_content.get("actions", {})

        labels = []
        for action_id in actions.keys():
            label = action_map.get(action_id, "unknown")
            labels.append(label)

        frame_labels[int(frame_id)] = labels

    return frame_labels

def classify_drowsiness(frame_labels):
    drowsy_keywords = [
        "eyes_state/close",
        "eyes_state/closing",
        "yawning/Yawning with hand",
        "yawning/Yawning without hand"
    ]

    binary_labels = {}

    for frame_id, labels in frame_labels.items():
        is_drowsy = any(label in drowsy_keywords for label in labels)
        binary_labels[frame_id] = 1 if is_drowsy else 0

    return binary_labels

def save_binary_csv(binary_labels, output="drowsy_labels.csv"):
    with open(output, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["frame_id", "label"])

        for frame_id in sorted(binary_labels.keys()):
            writer.writerow([frame_id, binary_labels[frame_id]])

if __name__ == "__main__":
    data = load_json(json_path)
    action_map = build_action_map(data)
    frame_labels = extract_frame_labels(data, action_map)
    binary_labels = classify_drowsiness(frame_labels)
    save_binary_csv(binary_labels)

    print("CSV file created successfully.")

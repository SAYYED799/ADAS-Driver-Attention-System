import cv2
import time

# Import real head detection
from head import get_head_status, release_head_resources

# Import joystick steering functions
from steeringanalysis import get_joystick_steering, analyze_steering


def main():
    try:
        while True:
            # ---- HEAD STATUS (already drawn inside head.py) ----
            head_status, frame = get_head_status()

            # ---- JOYSTICK STEERING ----
            angle = get_joystick_steering()
            steering_status, variance, freq = analyze_steering(angle)

            # ---- RISK FUSION LOGIC ----
            if head_status == "DISTRACTED" and steering_status == "DROWSY":
                risk = "HIGH RISK"
            elif head_status == "DISTRACTED" or steering_status == "DROWSY":
                risk = "MEDIUM RISK"
            else:
                risk = "SAFE"

            # ---- DISPLAY (No duplicate head text) ----
            if frame is not None:

                cv2.putText(frame, f"Steering: {steering_status}", (20, 100),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 0, 0), 2)

                cv2.putText(frame, f"Risk: {risk}", (20, 150),
                            cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 3)

                cv2.imshow("Driver Monitoring System", frame)

            print(f"Head: {head_status} | Steering: {steering_status} | Risk: {risk}")
            time.sleep(0.05)

            if cv2.waitKey(1) & 0xFF == 27:
                break
    finally:
        release_head_resources()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()

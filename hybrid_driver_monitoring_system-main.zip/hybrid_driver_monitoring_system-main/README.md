# ADAS Driver Attention System

An Advanced Driver Assistance System prototype for monitoring driver attention using computer vision, machine learning, head-pose/distraction checks, and steering-pattern analysis.

## Features

- Binary drowsiness classification using a ResNet18 model.
- Webcam-based live drowsiness monitoring.
- Face and eye based head-distraction detection.
- Joystick steering-pattern analysis for abnormal steering behavior.
- Risk fusion logic that combines ML, head-status, and steering-status signals.
- Training and evaluation plots for model analysis.

## Project Structure

```text
.
├── create_labels.py              # Converts OpenLABEL annotations to binary drowsiness labels
├── extract_frames.py             # Extracts video frames for training
├── train.py                      # Trains the drowsiness classifier
├── test.py                       # Runs model predictions on sample frames
├── visualize.py                  # Generates evaluation plots from training_log.json
├── webcam_demo.py                # Integrated webcam demo with ML, head, and steering checks
├── drowsy_labels.csv             # Prepared frame-level labels
├── plots/                        # Generated evaluation plots
└── minor/
    ├── main_driver_monitor.py    # Head + steering monitoring demo
    ├── head.py                   # Head distraction detection
    ├── steeringanalysis.py       # Joystick steering analysis
    └── face_landmarker.task      # MediaPipe task asset
```

## Setup

Create and activate a virtual environment:

```bash
python -m venv .venv
source .venv/bin/activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

## Usage

Generate labels from an annotation file:

```bash
python create_labels.py
```

Extract frames from a video:

```bash
python extract_frames.py
```

Train the model:

```bash
python train.py
```

Generate evaluation plots after training:

```bash
python visualize.py
```

Run the integrated webcam demo:

```bash
python webcam_demo.py
```

Run the head and steering monitor:

```bash
python minor/main_driver_monitor.py
```

## Notes

- `frames/`, video files, trained model weights, and training logs are ignored because they are generated or can be large.
- `webcam_demo.py` expects `drowsiness_model.pth` to exist in the project root. Generate it by running `train.py`.
- Steering analysis uses `pygame` and works best with a connected joystick or steering controller.
- Some scripts use local dataset paths and may need path updates for a different machine.
